export const currencies = ["CAD", "USD", "EUR", "GBP", "INR", "JPY"];
export const provinces = ["Alberta", "British Columbia", "Manitoba", "New Brunswick",
    "Newfoundland and Labrador", "Nova Scotia", "Ontario", "Prince Edward Island", "Quebec", "Saskatchewan"];
export const cities = ["Toronto", "Ottawa", "Mississauga", "Brampton", "Hamilton", "London", "Markham", "Vaughan", "Kitchener", "Windsor"];
export const countries = ["Canada"];