const Landing = (props) => {
    return <h1>Hello World</h1>;
}
export default Landing;